# ApacheKafkaTutorials
Example Code for Kafka Tutorials @ Learning Journal  
Visit https://learningjournal.guru/ for Tutorials
