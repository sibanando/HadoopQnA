openerp-install-scripts
=======================

OpenERP Install Scripts
