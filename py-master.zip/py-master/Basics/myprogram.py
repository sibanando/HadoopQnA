import sys
sys.path.append("C:\Code")
import functions as f
area = f.calculate_square_area(10)
area = f.calculate_triangle_area(5,10)
print(area)